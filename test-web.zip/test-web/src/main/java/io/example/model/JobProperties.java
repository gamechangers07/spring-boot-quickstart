package io.example.model;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;

@EnableConfigurationProperties
@ConfigurationProperties (prefix = "jobProperties")
public class JobProperties {

	 private String oozieClientURL;
	 private String nameNode;
	 private String jobTracker;
	 private String libpath;
	 private String hiveDb;
	 private String workflowDirPath;
	 
	 
	public String getOozieClientURL() {
		return oozieClientURL;
	}
	public void setOozieClientURL(String oozieClientURL) {
		this.oozieClientURL = oozieClientURL;
	}
	public String getNameNode() {
		return nameNode;
	}
	public void setNameNode(String nameNode) {
		this.nameNode = nameNode;
	}
	public String getJobTracker() {
		return jobTracker;
	}
	public void setJobTracker(String jobTracker) {
		this.jobTracker = jobTracker;
	}
	public String getLibpath() {
		return libpath;
	}
	public void setLibpath(String libpath) {
		this.libpath = libpath;
	}
	public String getHiveDb() {
		return hiveDb;
	}
	public void setHiveDb(String hiveDb) {
		this.hiveDb = hiveDb;
	}
	public String getWorkflowDirPath() {
		return workflowDirPath;
	}
	public void setWorkflowDirPath(String workflowDirPath) {
		this.workflowDirPath = workflowDirPath;
	} 
	
}
