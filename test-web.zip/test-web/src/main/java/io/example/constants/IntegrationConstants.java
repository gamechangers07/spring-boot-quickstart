package io.example.constants;

public class IntegrationConstants {

	  public static final String OOZIE_SYSTEM_LIBPATH = "oozie.use.system.libpath";
	  public static final String OOZIE_APP_PATH = "oozie.wf.application.path";
	  public static final String OOZIE_URL = "oozieUrl";
	  public static final String OOZIE_SHARE_LIB_PATH = "libPath";
	  public static final String JOB_TRACKER = "jobTracker";
	  public static final String NAME_NODE = "nameNode";
	  public static final String EXECUTION_ID = "executionId";
	  public static final String HIVE_DB = "hiveDb";
}
