package io.example.oozie;

import java.io.File;
import java.util.Properties;

import io.example.constants.IntegrationConstants;
import io.example.model.JobProperties;

public class OozieUtils {
	
	
	private  static Properties buildJobProperties(JobProperties jobProperties){
		
		String oozieAppPath = jobProperties.getNameNode() + File.separator + jobProperties.getWorkflowDirPath();
		Properties properties = new Properties();
		
		
		properties.setProperty(IntegrationConstants.OOZIE_URL, jobProperties.getOozieClientURL());
		properties.setProperty(IntegrationConstants.JOB_TRACKER, jobProperties.getJobTracker());
		properties.setProperty(IntegrationConstants.NAME_NODE, jobProperties.getNameNode());
		properties.setProperty(IntegrationConstants.OOZIE_SHARE_LIB_PATH, jobProperties.getLibpath());
		properties.setProperty(IntegrationConstants.OOZIE_APP_PATH, jobProperties.getJobTracker());
		properties.setProperty(IntegrationConstants.OOZIE_SYSTEM_LIBPATH, Boolean.TRUE.toString());
		
		properties.setProperty(IntegrationConstants.OOZIE_APP_PATH, oozieAppPath);
		

		
		return properties;
		
	}

}
