package io.example.hdp.model;

import javax.validation.constraints.NotNull;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;

@EnableConfigurationProperties
@ConfigurationProperties (prefix = "cluster")
public class VM {
	@NotNull(message = "error.nameNode.notnull")
	private String nameNode;
	private String  jobTracker; 
    private String  krb5Path;
    private String loginConfPath;
	@NotNull(message = "error.coreSiteXMLPath.notnull")
	private String coreSiteXMLPath;
	@NotNull(message = "error.hdfsSiteXMLPath.notnull")
	private String  hdfsSiteXMLPath;
	private String hdfsUrl;
	private String hdfsUserName;
	
	
	public String getNameNode() {
		return nameNode;
	}
	public String getJobTracker() {
		return jobTracker;
	}
	public String getKrb5Path() {
		return krb5Path;
	}
	public String getLoginConfPath() {
		return loginConfPath;
	}
	public String getCoreSiteXMLPath() {
		return coreSiteXMLPath;
	}
	public String getHdfsSiteXMLPath() {
		return hdfsSiteXMLPath;
	}
	public String getHdfsUrl() {
		return hdfsUrl;
	}
	public String getHdfsUserName() {
		return hdfsUserName;
	}
}
