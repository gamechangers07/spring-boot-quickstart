package io.example.hdp;

import org.springframework.boot.SpringApplication;

public class HdfsApplication {

	public static void main(String[] args) {
		SpringApplication.run(HdfsApplication.class, args); //create servlet container and host it

	}

}
