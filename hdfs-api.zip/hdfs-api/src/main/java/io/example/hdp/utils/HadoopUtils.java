package io.example.hdp.utils;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.springframework.beans.factory.annotation.Autowired;

import io.example.hdp.model.VM;

/**
 * 
 * @author Unkown
 *
 */

public class HadoopUtils {

@Autowired
private static VM vm;
	
	
public static Configuration buildConfiguration() {

        Configuration configuration = new Configuration();
        //configuration.set(hadoop.security.authentication, "kerberos");
        configuration.addResource(new Path(vm.getCoreSiteXMLPath()));
        configuration.addResource(new Path(vm.getHdfsSiteXMLPath()));
    //    System.setProperty("java.security.krb5.conf", "path");
      //  System.setProperty("java.security.auth.login.config", "path");

        return configuration;
    }
	

//public static FileSystem buildFileSystem(VM vm,	Configuration configuration){
//	
//	
//}


}
