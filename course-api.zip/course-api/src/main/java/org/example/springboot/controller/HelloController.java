package org.example.springboot.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * 
 * @author unknown
 *
 */
@RestController
public class HelloController {
	
	 // Default method is GET. Specify other method to use it
	@RequestMapping(value="/")
	public String sayGreeting(){
		return "Hi, Welcome to Spring Boot App!!!";
	}

}
