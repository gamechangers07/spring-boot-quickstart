package org.example.springboot.starter;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

/**
 * Sprint boot class. It will create the servlet container and host the app in the servlet container
 * Sets up default configuration
 * 
 * Starts Spring application context
 * 
 * Perform class path scan
 * 
 * Starts Tomcat Server
 * 
 * 
 * @author Unknown
 *
 */

@SpringBootApplication  // This denotes the starting point of Spring boot application
@ComponentScan(basePackages={"org.example.springboot.controller","org.example.springboot.service"})
public class CourseApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(CourseApiApplication.class, args); //create servlet container and host it
	}

}
